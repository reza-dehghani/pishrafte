#include<iostream>
#include<conio.h>
#include<string>
#include<fstream>
#include<Windows.h>
#include"system.h"
using namespace std;

void main()
{
	account bank;
	coin a;
	long id;
	int pass;
	int n;
	cout << "\n\n\n\n\n\n\n\n\n\n\n\t\t************************************************\n\t\t*   Welcome to the coin Bank Hackers system   *\n\t\t************************************************";
	Sleep(2000);
	system("cls");
		cout << "Enter: \n 1. for log in to your accont \n 2. to make a new accont \n 3. to exit: ";
		cin >> n;
		system("cls");
		switch (n)
		{
		case 1:
			cout << "Enter your account number: ";
			cin >> id;
			cout << "\nEnter password: ";
			cin >> pass;
			system("cls");
			switch (search(bank,a,id,pass))
			{
			case 0:
				cout << "Creat new account: \n";
				bank.input();
				show(bank, a);
				break;
			case 1:
				show(bank, a);
				Edit(bank, a, id, pass);
				break;
			default:
				break;
			}
			break;
		case 2:
			cout << "Creat new account: \n";
			bank.input();
			system("cls");
			show(bank, a);
			save(bank, a);
			break;
		case 3:
			break;
		default:
			cout << "\n____ERROR_____";
		}
	_getch;
	return;
}