#include<iostream>
#include<conio.h>
#include<fstream>
#include<string>
using namespace std;
struct date
{
	unsigned int day;
	unsigned int month;
	unsigned int year;
};
struct copy2
{
	long id;
	int pass;
	unsigned int day, month, year, rial_cash, toman_cash, qran_cash;
	string ok;
};
class coin;
class account
{
protected:
	string f_name;
	string l_name;
	long id_num;
	int password;
	date Date;
	copy2 inform[100];
public:
	
	void id_pass()
	{
		int i;
		ifstream file("copy.txt");
		for (i = 0;; i++)
		{
			file >> inform[i].ok;
			if (inform[i].ok != "ok")
				break;
			file >> inform[i].id;
			file >> inform[i].pass;
			file >> inform[i].day;
			file >> inform[i].month;
			file >> inform[i].year;
			file >> inform[i].rial_cash;
			file >> inform[i].toman_cash;
			file >> inform[i].qran_cash;
		}
		id_num = inform[i - 1].id + 1;
		password = inform[i - 1].pass + 1;
	}
	void input()
	{
		string a;
		cout << "\nFirst name: ";
		cin.ignore();
		getline(cin, f_name);
		cout << "Last name: ";
		getline(cin, l_name);
		cout << "Date:\nDay: ";
		cin >> Date.day;
		cout << "Month: ";
		cin >> Date.month;
		cout << "Year(for example 1399): ";
		cin >> Date.year;
		id_pass();
		cout << "Your account was registered with number" << id_num << " and password " << password<<'\n'<<"Write down your account information";
		cout << "\nEnter something to continue: ";
		cin >> a;

	}
	friend void save(account,coin);
	friend int search(account,coin&,long,int);
	friend void show(account, coin&);
};
class coin :public account
{
	unsigned int cash_rial, cash_toman, cash_qran;
	date Date;
public:
	coin()
	{
		cash_rial = 0;
		cash_toman = 0;
		cash_qran = 0;
	}
	void deposit_rial(unsigned int x)
	{
		cash_rial = cash_rial + x;
		cout << "\n____Done____";
	}
	void deposit_toman(unsigned int x)
	{
		cash_toman = cash_toman + x;
		cout << "\n____Done____";
	}
	void deposit_qran(unsigned int x)
	{
		cash_qran = cash_qran + x;
		cout << "\n____Done____";
	}
	void Profit(unsigned int day, unsigned int month, unsigned int year)
	{
		day = (year - Date.year) * 360 + (month - Date.month) * 30 + (day - Date.day);
		if (day >= 30)
		{
			cash_rial = cash_rial + 0.1 * cash_rial;
			cash_toman = cash_toman + 0.25 * cash_toman;
			cash_qran = cash_qran + 0.5 * cash_qran;
		}
	}
	void deduction_rial(unsigned int x)
	{
		if (x >= cash_rial)
		{
			cash_rial = cash_rial - x;
			cout << "\n____Done____\nGet money";
		}
		else
			cout << "\nInventory is not enough";
	}
	void deduction_toman(unsigned int x)
	{
		if (x >= cash_toman)
		{
			cash_toman = cash_toman - x;
			cout << "\n____Done____\nGet money";
		}
		else
			cout << "\nInventory is not enough";
		}
	void deduction_qran(unsigned int x)
	{
		if (x >= cash_qran)
		{
			cash_qran = cash_qran - x;
			cout << "\n____Done____\nGet money";
		}
		else
			cout << "\nInventory is not enough";
		}
	friend void save(account,coin);
	friend int search(account, coin&,long,int);
	friend void show(account, coin&);
	friend void Edit(account, coin, long,int);
};
void save(account p,coin q)
{
	int i;
	copy2 inform[100];
	ifstream info("copy.txt",ios::in);
	for (i = 0;; i++)
	{
		info >> inform[i].ok;
		if (inform[i].ok != "ok")
			break;
		info >> inform[i].id;
		info >> inform[i].pass;
		info >> inform[i].day;
		info >> inform[i].month;
		info >> inform[i].year;
		info >> inform[i].rial_cash;
		info >> inform[i].toman_cash;
		info >> inform[i].qran_cash;
	}
	info.close();
	ofstream file("copy.txt",ios::out);
	for (int j = 0; j < i; j++)
		file << "ok" << " " << inform[j].id << " " << inform[j].pass << " " << inform[j].day << " " << inform[j].month << " " << inform[j].year << " " << inform[j].rial_cash << " " << inform[j].toman_cash << " " << inform[j].qran_cash << " ";
	file << "ok" << " " << p.id_num << " " <<p.password << " " << p.Date.day <<" "<<p.Date.month <<" "<< p.Date.year << " " << q.cash_rial << " "<<q.cash_toman<<" "<<q.cash_qran<<" ";
	file.close();
}
int search(account p, coin &q,long id,int pass)
{
	int i;
	int n;
	copy2 inform[100];
	ifstream info("copy.txt",ios::in);
	for (;;)
	{
		for (i = 0;; i++)
		{
			info >> inform[i].ok;
			if (inform[i].ok != "ok")
			{
				cout << "__There is no account with this number__\n";
				n = 0;
				break;
			}
			info >> inform[i].id;
			info >> inform[i].pass;
			info >> inform[i].day;
			info >> inform[i].month;
			info >> inform[i].year;
			info >> inform[i].rial_cash;
			info >> inform[i].toman_cash;
			info >> inform[i].qran_cash;
			if (inform[i].id == id)
			{
				n = 1;
				break;
			}
		}
		switch (n)
		{
		case 0:
			cout << "Enter 1 to retry and 2 to register and create an account:";
			cin >> n;
			switch (n)
			{
			case 1:
				system("cls");
				cout << "\nRtry(Enter account number): ";
				cin >> id;
				continue;
			case 2:
				return 0;
			default:
				system("cls");
				cout << "\n______ERROR______";
				cout << "\nRtry(Enter account number): ";
				cin >> id;
				continue;
			}
		case 1:
			for (;;)
			{
				if (pass == inform[i].pass)
				{
					q.Date.day = inform[i].day;
					q.Date.month = inform[i].month;
					q.Date.year = inform[i].year;
					q.cash_rial = inform[i].rial_cash;
					q.cash_toman = inform[i].toman_cash;
					q.cash_qran = inform[i].qran_cash;
					return 1;
				}
				else
				{
					cout << "\nWrong password\nEnter 1 to exit and 2 to retest:";
					cin >> n;
					switch (n)
					{
					case 1:
						return 0;
					case 2:
						cout << "\nEnter password again: ";
						cin >> pass;
						continue;
					default:
						cout << "\n______ERROR______";
						return 0;
					}
				}
			}
		default:
			break;
		}
	}

}
void show(account p,coin& q)
{
	unsigned int day,month, year;
	 unsigned int x;
	cout << "Enter the date: \n";
	cout << "Day: ";
	cin >> day;
	cout << "\nMonth: ";
	cin >> month;
	cout << "\nYear (for example 1399): ";
	cin >> year;
	system("cls");
	q.Profit(day, month, year);
	cout << "Your account balance:\nRial: " << q.cash_rial << "\nToman: " << q.cash_toman << "\nQran: " << q.cash_qran<<"\n\n";
	
	for (;;)
	{
		cout << "Enter\n1.To buy Rials number \n2.To withdraw from the inventory of Rials number \n3.To buy Tomans number  \n4.To withdraw from the inventory of Tomans number \n5.To buy Qrans number \n6.To withdraw from the inventory of Qrans number\n7.Exit";
		cout << "\n : ";
		int n;
		cin >> n;
		system("cls");
		switch (n)
		{
		case 1:
			cout << "How much do you want to deposit? ";
			cin >> x;
			q.deposit_rial(x);
			cout << "\nTo return, enter the number 1 to exit the number 2: ";
			cin >> n;
			system("cls");
			if (n == 1)
				continue;
			else
				return;
		case 2:
			cout << "How Much Money Do You Want to Make? ";
			cin >> x;
			q.deduction_rial(x);
			cout << "\nTo return, enter the number 1 to exit the number 2: ";
			cin >> n;
			system("cls");
			if (n == 1)
				continue;
			else
				return;
		case 3:
			cout << "How much do you want to deposit? ";
			cin >> x;
			q.deposit_toman(x);
			cout << "\nTo return, enter the number 1 to exit the number 2: ";
			cin >> n;
			system("cls");
			if (n == 1)
				continue;
			else
				return;
		case 4:
			cout << "How Much Money Do You Want to Make? ";
			cin >> x;
			q.deduction_toman(x);
			cout << "\nTo return, enter the number 1 to exit the number 2: ";
			cin >> n;
			system("cls");
			if (n == 1)
				continue;
			else
				return;
		case 5:
			cout << "How much do you want to deposit? ";
			cin >> x;
			q.deposit_qran(x);
			cout << "\nTo return, enter the number 1 to exit the number 2: ";
			cin >> n;
			system("cls");
			if (n == 1)
				continue;
			else
				return;
		case 6:
			cout << "\nHow Much Money Do You Want to Make? ";
			cin >> x;
			q.deduction_qran(x);
			cout << "\nTo return, enter the number 1 to exit the number 2: ";
			cin >> n;
			system("cls");
			if (n == 1)
				continue;
			else
				return;
		case 7:
			return;
		default:
			cout << "\n____ERROR____";
			continue;
		}
	}
}
void Edit(account p, coin q, long id,int pass)
{
	int day, mouth, year;
	int i;
	copy2 inform[100];
	ifstream info("copy.txt",ios::in);
	for (i = 0;; i++)
	{
		info >> inform[i].ok;
		if (inform[i].ok != "ok")
			break;
		info >> inform[i].id;
		info >> inform[i].pass;
		info >> inform[i].day;
		info >> inform[i].month;
		info >> inform[i].year;
		info >> inform[i].rial_cash;
		info >> inform[i].toman_cash;
		info >> inform[i].qran_cash;
		if (inform[i].id == id)
		{
			day = inform[i].day;
			mouth = inform[i].month;
			year = inform[i].year;
		}
	}
	info.close();
	ofstream file("copy.txt",ios::out);
	for (int j = 0; j < i; j++)
	{
		if (inform[j].id == id)
		{
			file << "ok" << " " << id << " " << pass << " " << day << " " << mouth << " " << year << " " << q.cash_rial << " " << q.cash_toman << " " << q.cash_qran << " ";
			continue;
		}
		file << "ok" << " " << inform[j].id << " " << inform[j].pass << " " << inform[j].day << " " << inform[j].month << " " << inform[j].year << " " << inform[j].rial_cash << " " << inform[j].toman_cash << " " << inform[j].qran_cash << " ";
	}
}